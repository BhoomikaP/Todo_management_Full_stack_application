import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BasicAuthenticationService } from '../service/basic-authentication.service';
import { HardcoadedAuthenticationService } from '../service/hardcoaded-authentication.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit{
  user = "in26"
  
  pass = ""
  errormessage="Invalid creds"
  invalidLogin = false 
  constructor(private router: Router , 
    private hardcodedAuthenticationService: HardcoadedAuthenticationService,
    private basicAuthenticationservice: BasicAuthenticationService) {


  }
  
  ngOnInit(){
    
  }
  handleLogin(){
    //if(this.user=="in2" && this.pass=="yun")
    if(this.hardcodedAuthenticationService.authenticate(this.user,this.pass))
    {
      
      this.router.navigate(['welcome', this.user])
      this.invalidLogin=false}
    else{
    this.invalidLogin=true }
  }
  handleJWTBasicAuthLogin(){
    //if(this.user=="in2" && this.pass=="yun")
    this.basicAuthenticationservice.executeJWTAuthenticationservice(this.user,this.pass)
      .subscribe(
        data => {
          console.log(data)
          this.router.navigate(['welcome', this.user])
      this.invalidLogin=false
        },
        error =>{
          console.log(error)
          this.invalidLogin=true 
        }
      )
   }
  }