import { NONE_TYPE } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Todo } from '../list-todos/list-todos.component';
import { BasicAuthenticationService } from '../service/basic-authentication.service';
import { TodoDataService } from '../service/data/todo-data.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  id: number=0;
  
  todo: Todo={id:0,description:"",done:false,targetDate:new Date};
  constructor(private todoService: TodoDataService,
    private route:ActivatedRoute,
    private router: Router,
    private basicAuthenticationService : BasicAuthenticationService){
    
  }
  
  ngOnInit(){
    let user = this.basicAuthenticationService.getAuthenticatedUser();
    this.todo= new Todo(this.id," ",false,new Date())
    this.id=this.route.snapshot.params['id'];
    if(this.id!=-1){
      this.todoService.retrieveTodo(user,this.id ).subscribe(
        data => this.todo = data
      )
    }
  }
  saveTodo(){
    if(this.id==-1){
      let user = this.basicAuthenticationService.getAuthenticatedUser();
      this.todoService.createTodo(user,this.todo ).subscribe(
        data => {
          console.log(data)
          this.router.navigate(['todos'])
        }
      )
    }else{
      let user = this.basicAuthenticationService.getAuthenticatedUser();
    this.todoService.updateTodo(user,this.id,this.todo).subscribe(
      data => {
        console.log(data)
        this.router.navigate(['todos'])
      }
    )
  }
}
}