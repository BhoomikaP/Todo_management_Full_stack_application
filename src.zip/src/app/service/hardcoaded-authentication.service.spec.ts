import { TestBed } from '@angular/core/testing';

import { HardcoadedAuthenticationService } from './hardcoaded-authentication.service';

describe('HardcoadedAuthenticationService', () => {
  let service: HardcoadedAuthenticationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HardcoadedAuthenticationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
