import { HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BasicAuthenticationService } from '../basic-authentication.service';

@Injectable({
  providedIn: 'root'
})
export class HttpIntercepterBasicAuthService implements HttpInterceptor{

  constructor(
    private basicAuthenticationService : BasicAuthenticationService
  ) { }
  intercept(request: HttpRequest<any>, next: HttpHandler){
      //let basicAuthHeaderString = 'Basic '+window.btoa(user+':'+pass);
      let basicAuthHeaderString = this.basicAuthenticationService.getAuthenticatedToken();
      let user = this.basicAuthenticationService.getAuthenticatedUser();
      
      if(basicAuthHeaderString && user){
        request=request.clone({
          setHeaders : {
            Authorization : basicAuthHeaderString
          }
        })
      }
      return next.handle(request);
    }
  }

