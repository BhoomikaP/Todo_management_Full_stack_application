import {HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable } from '@angular/core';
export class HelloWorldBean{
  constructor(public message:string){}
}
@Injectable({
  providedIn: 'root'
})
export class WelcomeDataService {

  constructor(private http: HttpClient) { }
  executeHelloWorldBeanService(){
    return this.http.get<HelloWorldBean>("http://localhost:8080/hello-world-bean")
    //console.log("bean")
  }
  executeHelloWorldServicewithpath(name:any){
    let basicAuthHeaderString = this.createBasicAuthenticationHttpHeader();
    let header = new HttpHeaders({
      Authorization: basicAuthHeaderString
    }
      
    )
    
    return this.http.get(`http://localhost:8080/hello-world/path-variable/${name}`,
    {headers: header});
    
    //console.log("bean")
  }
  createBasicAuthenticationHttpHeader() {
    let user='in26'
    let pass='yun'
    let basicAuthHeaderString = 'Basic '+window.btoa(user+':'+pass);
    return basicAuthHeaderString;
  }
}
