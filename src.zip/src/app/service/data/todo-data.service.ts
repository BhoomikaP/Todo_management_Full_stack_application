import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TODO_JPA_API_URL } from 'src/app/app.constants';
import { Todo } from 'src/app/list-todos/list-todos.component';
@Injectable({
  providedIn: 'root'
})
export class TodoDataService {

  constructor(
    private http:HttpClient
  ) { }
  retrieveAllTodos(user:any){
    return this.http.get<Todo[]>(`${TODO_JPA_API_URL}/users/${user}/todos`)
    //console.log("bean")
  }
  deleteTodo(user:any, id:any){
    return this.http.delete(`${TODO_JPA_API_URL}/users/${user}/todos/${id}`)
  }
  retrieveTodo(user:any, id:any){
    return this.http.get<Todo>(`${TODO_JPA_API_URL}/users/${user}/todos/${id}`)
  }
  updateTodo(user:any, id:any, todo: any){
    return this.http.put<Todo>(`${TODO_JPA_API_URL}/users/${user}/todos/${id}`, todo)
  }
  createTodo(user:any, todo: any){
    return this.http.post<Todo>(`${TODO_JPA_API_URL}/users/${user}/todos`, todo)
  }
}
