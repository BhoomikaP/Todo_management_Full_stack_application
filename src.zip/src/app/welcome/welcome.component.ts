import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppComponent } from '../app.component';
import { HelloWorldBean, WelcomeDataService } from '../service/data/welcome-data.service';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent {
  message = "i dont know"
  welcomeMessageFromservice=""
  name=""
  constructor(private route:ActivatedRoute,
    private service: WelcomeDataService){
    
  }
  
  ngOnInit() {
    
    //console.log(this.message)
    //this.route.snapshot.params['name']
  this.name = this.route.snapshot.params['name']
}
getWelcomeMessage(){
  //console.log(this.service.executeHelloWorldBeanService());
  this.service.executeHelloWorldBeanService().subscribe(
  response => this.handleSuccessfulResponse(response),
  error=> this.handleErrorResponse(error) 
  );
  //console.log("get welcome")
}
getWelcomeMessagewithparameter(){
  //console.log(this.service.executeHelloWorldBeanService());
  this.service.executeHelloWorldServicewithpath(this.name).subscribe(
  response => this.handleSuccessfulResponse(response),
  error=> this.handleErrorResponse(error) 
  );
  //console.log("get welcome")
}
handleSuccessfulResponse(response: any){
  this.welcomeMessageFromservice = response.message;
  console.log(response.message)
}
handleErrorResponse(error: any){
  //console.log(error.message);
  this.welcomeMessageFromservice = error.error.message;
}
}
