import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { BasicAuthenticationService } from '../service/basic-authentication.service';
import { TodoDataService } from '../service/data/todo-data.service';

export class Todo {
  constructor(
    public id: number,
    public description: string,
    public done: boolean,
    public targetDate: Date
  ) {

  }
}

@Component({
  selector: 'app-list-todos',
  templateUrl: './list-todos.component.html',
  styleUrls: ['./list-todos.component.css']
})
export class ListTodosComponent {
  
  todos: Todo[]= [];
    message: String="";
  
  constructor(
    private todoService:TodoDataService,
    private router: Router,
    private basicAuthenticationService : BasicAuthenticationService
  ){ }
    ngOnInit(){
      this.refreshTodos();
    }
    refreshTodos(){
      let user = this.basicAuthenticationService.getAuthenticatedUser();
      this.todoService.retrieveAllTodos(user).subscribe(
        response => {
          console.log(response)
          this.todos=response;
        }
      )
    }
    deleteTodo(id:any){
      let user = this.basicAuthenticationService.getAuthenticatedUser();
      console.log(`delete todo ${id}`)
    this.todoService.deleteTodo(user,id).subscribe(
      (response: any) => {
        console.log(response);
        this.message=`Delete of Todo ${id} successful`
        this.refreshTodos();
      }
    )
    }
    updateTodo(id:any) {
      console.log(`update $(id)`)
      this.router.navigate(['todos',id])
    }
    addTodo(){
      this.router.navigate(['todos',-1])
    }
}
