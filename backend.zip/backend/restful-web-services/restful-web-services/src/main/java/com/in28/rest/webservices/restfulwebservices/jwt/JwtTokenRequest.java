package com.in28.rest.webservices.restfulwebservices.jwt;

import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins="http://localhost:4200")
public record JwtTokenRequest(String username, String password) {}


