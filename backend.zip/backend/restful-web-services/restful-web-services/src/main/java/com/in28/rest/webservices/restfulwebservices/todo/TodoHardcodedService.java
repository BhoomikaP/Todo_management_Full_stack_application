package com.in28.rest.webservices.restfulwebservices.todo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class TodoHardcodedService {
private static List<Todo> todos=new ArrayList();
private static long idcounter=0;
//static {
//	todos.add(new Todo(++idcounter,"in26","Learn to dance", LocalDate,false));
//	todos.add(new Todo(++idcounter,"in26","Learn java", LocalDate(),false));
//	todos.add(new Todo(++idcounter,"in26","Learn to angular", LocalDate(),false));
//	todos.add(new Todo(++idcounter,"in26","Learn to angular", LocalDate(),false));
//}
public List<Todo>findAll()
{
	return todos;
}
public Todo deleteById(long id) {
	Todo todo = findById(id);
	if(todo==null) return null;
	if(todos.remove(todo))
	return todo;
	return null;
}
public Todo save(Todo todo) {
	if(todo.getId()==-1 || todo.getId()==0) {
		todo.setId(++idcounter);
		todos.add(todo);
	}
	else {
		deleteById(todo.getId());
		todos.add(todo);
	}
	return todo;
}
//public Todo updateById(long id) {
//	Todo todo = findById(id);
//	if(todo==null) return null;
//	if(todos.remove(todo))
//	return todo;
//	return null;
//}
Todo findById(long id) {
	// TODO Auto-generated method stub
	for(Todo todo:todos) {
		if(todo.getId()==id) {
			return todo;
		}
	}
	return null;
}
}
