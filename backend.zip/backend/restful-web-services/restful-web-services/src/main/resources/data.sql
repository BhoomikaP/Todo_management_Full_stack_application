insert into todo(id, username,description, target_date, is_done)
values(10001,'in26','learn JPA', CURRENT_DATE,false);

insert into todo(id, username,description, target_date, is_done)
values(10002,'in26','learn data JPA', CURRENT_DATE,false);

insert into todo(id, username,description, target_date, is_done)
values(10003,'in26','learn jp JPA', CURRENT_DATE,false);